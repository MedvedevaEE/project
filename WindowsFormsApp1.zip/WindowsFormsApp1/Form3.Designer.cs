﻿
namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавлениеЧитателейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.работаСКнигамиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавлениеКнигиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.списаниеКнигиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.абонементToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поискToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.книгToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.читателейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.абонементаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem,
            this.добавлениеЧитателейToolStripMenuItem,
            this.работаСКнигамиToolStripMenuItem,
            this.абонементToolStripMenuItem,
            this.поискToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(11, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(1924, 45);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(181, 39);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // добавлениеЧитателейToolStripMenuItem
            // 
            this.добавлениеЧитателейToolStripMenuItem.Name = "добавлениеЧитателейToolStripMenuItem";
            this.добавлениеЧитателейToolStripMenuItem.Size = new System.Drawing.Size(297, 39);
            this.добавлениеЧитателейToolStripMenuItem.Text = "Добавление читателей";
            this.добавлениеЧитателейToolStripMenuItem.Click += new System.EventHandler(this.добавлениеЧитателейToolStripMenuItem_Click);
            // 
            // работаСКнигамиToolStripMenuItem
            // 
            this.работаСКнигамиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавлениеКнигиToolStripMenuItem,
            this.списаниеКнигиToolStripMenuItem});
            this.работаСКнигамиToolStripMenuItem.Name = "работаСКнигамиToolStripMenuItem";
            this.работаСКнигамиToolStripMenuItem.Size = new System.Drawing.Size(231, 39);
            this.работаСКнигамиToolStripMenuItem.Text = "Работа с книгами";
            // 
            // добавлениеКнигиToolStripMenuItem
            // 
            this.добавлениеКнигиToolStripMenuItem.Name = "добавлениеКнигиToolStripMenuItem";
            this.добавлениеКнигиToolStripMenuItem.Size = new System.Drawing.Size(315, 40);
            this.добавлениеКнигиToolStripMenuItem.Text = "Добавление книги";
            this.добавлениеКнигиToolStripMenuItem.Click += new System.EventHandler(this.добавлениеКнигиToolStripMenuItem_Click);
            // 
            // списаниеКнигиToolStripMenuItem
            // 
            this.списаниеКнигиToolStripMenuItem.Name = "списаниеКнигиToolStripMenuItem";
            this.списаниеКнигиToolStripMenuItem.Size = new System.Drawing.Size(315, 40);
            this.списаниеКнигиToolStripMenuItem.Text = "Списание книги";
            this.списаниеКнигиToolStripMenuItem.Click += new System.EventHandler(this.списаниеКнигиToolStripMenuItem_Click);
            // 
            // абонементToolStripMenuItem
            // 
            this.абонементToolStripMenuItem.Name = "абонементToolStripMenuItem";
            this.абонементToolStripMenuItem.Size = new System.Drawing.Size(157, 39);
            this.абонементToolStripMenuItem.Text = "Абонемент";
            this.абонементToolStripMenuItem.Click += new System.EventHandler(this.абонементToolStripMenuItem_Click);
            // 
            // поискToolStripMenuItem
            // 
            this.поискToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.книгToolStripMenuItem,
            this.читателейToolStripMenuItem,
            this.абонементаToolStripMenuItem});
            this.поискToolStripMenuItem.Name = "поискToolStripMenuItem";
            this.поискToolStripMenuItem.Size = new System.Drawing.Size(98, 39);
            this.поискToolStripMenuItem.Text = "Поиск";
            // 
            // книгToolStripMenuItem
            // 
            this.книгToolStripMenuItem.Name = "книгToolStripMenuItem";
            this.книгToolStripMenuItem.Size = new System.Drawing.Size(246, 40);
            this.книгToolStripMenuItem.Text = "Книг";
            this.книгToolStripMenuItem.Click += new System.EventHandler(this.книгToolStripMenuItem_Click);
            // 
            // читателейToolStripMenuItem
            // 
            this.читателейToolStripMenuItem.Name = "читателейToolStripMenuItem";
            this.читателейToolStripMenuItem.Size = new System.Drawing.Size(246, 40);
            this.читателейToolStripMenuItem.Text = "Читателей";
            this.читателейToolStripMenuItem.Click += new System.EventHandler(this.читателейToolStripMenuItem_Click);
            // 
            // абонементаToolStripMenuItem
            // 
            this.абонементаToolStripMenuItem.Name = "абонементаToolStripMenuItem";
            this.абонементаToolStripMenuItem.Size = new System.Drawing.Size(246, 40);
            this.абонементаToolStripMenuItem.Text = "Абонемента";
            this.абонементаToolStripMenuItem.Click += new System.EventHandler(this.абонементаToolStripMenuItem_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Электронный каталог библиотеки";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form3_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem работаСКнигамиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавлениеКнигиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem списаниеКнигиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавлениеЧитателейToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem абонементToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поискToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem книгToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem читателейToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem абонементаToolStripMenuItem;
    }
}