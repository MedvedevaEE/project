﻿
namespace WindowsFormsApp1
{
    partial class FormPoickBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iSBNББКDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОАвтораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.авторскийКодDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.описаниеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.разделDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.подразделDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоЭкземпляровDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЭкземпляраDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаВнесенияВФондDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.книгиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.книгиBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(559, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(403, 38);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(180, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(313, 33);
            this.label1.TabIndex = 4;
            this.label1.Text = "Введите данные для поиска";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iSBNББКDataGridViewTextBoxColumn,
            this.фИОАвтораDataGridViewTextBoxColumn,
            this.авторскийКодDataGridViewTextBoxColumn,
            this.описаниеDataGridViewTextBoxColumn,
            this.разделDataGridViewTextBoxColumn,
            this.подразделDataGridViewTextBoxColumn,
            this.количествоЭкземпляровDataGridViewTextBoxColumn,
            this.ценаЭкземпляраDataGridViewTextBoxColumn,
            this.датаВнесенияВФондDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.книгиBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 231);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1900, 367);
            this.dataGridView1.TabIndex = 6;
            // 
            // iSBNББКDataGridViewTextBoxColumn
            // 
            this.iSBNББКDataGridViewTextBoxColumn.DataPropertyName = "ISBN/ББК";
            this.iSBNББКDataGridViewTextBoxColumn.HeaderText = "ISBN/ББК";
            this.iSBNББКDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iSBNББКDataGridViewTextBoxColumn.Name = "iSBNББКDataGridViewTextBoxColumn";
            // 
            // фИОАвтораDataGridViewTextBoxColumn
            // 
            this.фИОАвтораDataGridViewTextBoxColumn.DataPropertyName = "ФИО автора";
            this.фИОАвтораDataGridViewTextBoxColumn.HeaderText = "ФИО автора";
            this.фИОАвтораDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.фИОАвтораDataGridViewTextBoxColumn.Name = "фИОАвтораDataGridViewTextBoxColumn";
            // 
            // авторскийКодDataGridViewTextBoxColumn
            // 
            this.авторскийКодDataGridViewTextBoxColumn.DataPropertyName = "Авторский код";
            this.авторскийКодDataGridViewTextBoxColumn.HeaderText = "Авторский код";
            this.авторскийКодDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.авторскийКодDataGridViewTextBoxColumn.Name = "авторскийКодDataGridViewTextBoxColumn";
            // 
            // описаниеDataGridViewTextBoxColumn
            // 
            this.описаниеDataGridViewTextBoxColumn.DataPropertyName = "Описание";
            this.описаниеDataGridViewTextBoxColumn.HeaderText = "Описание";
            this.описаниеDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.описаниеDataGridViewTextBoxColumn.Name = "описаниеDataGridViewTextBoxColumn";
            // 
            // разделDataGridViewTextBoxColumn
            // 
            this.разделDataGridViewTextBoxColumn.DataPropertyName = "Раздел";
            this.разделDataGridViewTextBoxColumn.HeaderText = "Раздел";
            this.разделDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.разделDataGridViewTextBoxColumn.Name = "разделDataGridViewTextBoxColumn";
            // 
            // подразделDataGridViewTextBoxColumn
            // 
            this.подразделDataGridViewTextBoxColumn.DataPropertyName = "Подраздел";
            this.подразделDataGridViewTextBoxColumn.HeaderText = "Подраздел";
            this.подразделDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.подразделDataGridViewTextBoxColumn.Name = "подразделDataGridViewTextBoxColumn";
            // 
            // количествоЭкземпляровDataGridViewTextBoxColumn
            // 
            this.количествоЭкземпляровDataGridViewTextBoxColumn.DataPropertyName = "Количество экземпляров";
            this.количествоЭкземпляровDataGridViewTextBoxColumn.HeaderText = "Количество экземпляров";
            this.количествоЭкземпляровDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.количествоЭкземпляровDataGridViewTextBoxColumn.Name = "количествоЭкземпляровDataGridViewTextBoxColumn";
            // 
            // ценаЭкземпляраDataGridViewTextBoxColumn
            // 
            this.ценаЭкземпляраDataGridViewTextBoxColumn.DataPropertyName = "Цена экземпляра";
            this.ценаЭкземпляраDataGridViewTextBoxColumn.HeaderText = "Цена экземпляра";
            this.ценаЭкземпляраDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ценаЭкземпляраDataGridViewTextBoxColumn.Name = "ценаЭкземпляраDataGridViewTextBoxColumn";
            // 
            // датаВнесенияВФондDataGridViewTextBoxColumn
            // 
            this.датаВнесенияВФондDataGridViewTextBoxColumn.DataPropertyName = "Дата внесения в фонд";
            this.датаВнесенияВФондDataGridViewTextBoxColumn.HeaderText = "Дата внесения в фонд";
            this.датаВнесенияВФондDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.датаВнесенияВФондDataGridViewTextBoxColumn.Name = "датаВнесенияВФондDataGridViewTextBoxColumn";
            // 
            // книгиBindingSource
            // 
            this.книгиBindingSource.DataMember = "Книги";
            // 
            // dataSet
            // 
            // 
            // книгиTableAdapter
            // 
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(1084, 701);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 50);
            this.button1.TabIndex = 7;
            this.button1.Text = "ЭКСПОРТ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(1084, 73);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 50);
            this.button2.TabIndex = 8;
            this.button2.Text = "ПОИСК";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FormPoickBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "FormPoickBook";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Поиск книги";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormPoickBook_FormClosing);
            this.Load += new System.EventHandler(this.FormPoickBook_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.книгиBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource книгиBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn инвентариальныйНомерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iSBNББКDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОАвтораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn авторскийКодDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn описаниеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn разделDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn подразделDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоЭкземпляровDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЭкземпляраDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаВнесенияВФондDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}