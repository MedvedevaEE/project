﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Configuration;
//using Microsoft.Data.SqlClient;



namespace WindowsFormsApp1
{
    public partial class FormAddReaders : Form
    {
        public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source = библиотека.mdb";
        private OleDbConnection myConnection;

        public FormAddReaders()
        {
            InitializeComponent();
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
        }

        private void FormAddReaders_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "библиотекаDataSet.Читатели". При необходимости она может быть перемещена или удалена.
            //this.читателиTableAdapter.Fill(this.библиотекаDataSet.Читатели);

        }

        private void button1_Click(object sender, EventArgs e)
        {            
            
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            long n = Convert.ToInt64(maskedTextBox1.Text);
            string f = textBox2.Text;
            string i = textBox3.Text;
            string o = textBox4.Text;
            string sg = comboBox1.Text;
            //string sg = textBox5.Text;
            DateTime dp = Convert.ToDateTime(maskedTextBox2.Text);
            DateTime dv = Convert.ToDateTime(maskedTextBox3.Text);
            //string query = "INSERT INTO Читатели ([Читательский номер], Фамилия, Имя, Отчество, Специальность/Должность, [Дата поступления], [Дата выпуска]) VALUES (" + n + ",'" + f + "','" + i + "','" + o + "','" + sg + "'," + dp + "," + dv + ")";
//            SqlCommand cmd = new SqlCommand("INSERT INTO Читатели ([Читательский номер], Фамилия, Имя, Отчество, Специальность/Должность, [Дата поступления], [Дата выпуска]) VALUES (" + n + ",'" + f + "','" + i + "','" + o + "','" + sg + "'," + dp + "," + dv + ")", myConnection);
            //OleDbDataAdapter command = new OleDbDataAdapter(query, myConnection);
 //           SqlDataReader reader = cmd.ExecuteReader();

//            command.ExecuteNonQuery();
            MessageBox.Show("Читатель добавлен");
            DataTable qw = new DataTable();
//            command.Fill(qw);
            dataGridView1.DataSource = qw;
            //command.ExecuteNonQuery(qw);
            //this.читателиTableAdapter.Fill(this.библиотекаDataSet.Читатели);
            maskedTextBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            maskedTextBox2.Clear();
            maskedTextBox3.Clear();
        }
    }
}
