﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class FormAbonement : Form
    {
        public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= библиотека.mdb";
        private OleDbConnection myConnection;

        public FormAbonement()
        {
            InitializeComponent();
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
        }

        private void FormAbonement_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "библиотекаDataSet.Абонемент". При необходимости она может быть перемещена или удалена.
            //this.абонементTableAdapter.Fill(this.библиотекаDataSet.Абонемент);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "библиотекаDataSet.Абонемент". При необходимости она может быть перемещена или удалена.
            //this.абонементTableAdapter.Fill(this.библиотекаDataSet.Абонемент);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            myConnection = new OleDbConnection(connectString);
            //myConnection.Open();
            string nа = Convert.ToString(maskedTextBox5.Text);
            string rn = Convert.ToString(maskedTextBox2.Text);
            long isbn = Convert.ToInt64(maskedTextBox1.Text);
            string dp = Convert.ToString(maskedTextBox3.Text);
            string dv = Convert.ToString(maskedTextBox4.Text);
            string query = "INSERT INTO Абонемент ([Номер абонемента], [Читательский номер], ISBN/ББК, [Дата выдачи], Количество) VALUES ('" + nа + "','" + rn + "'," + isbn + ",'" + dp + "','" + dv + "')";            
            OleDbDataAdapter command = new OleDbDataAdapter(query, myConnection);
            myConnection.Open();
            //query.ExecuteNonQuery();
            MessageBox.Show("Абонемент добавлен");
            this.абонементTableAdapter.Fill(this.библиотекаDataSet.Абонемент);            
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            maskedTextBox3.Clear();
            maskedTextBox4.Clear();
            maskedTextBox5.Clear();
        }
    }
}
