﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using Excel = Microsoft.Office.Interop.Excel;

namespace WindowsFormsApp1
{
    public partial class FormPoickBook : Form
    {
        public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= библиотека.mdb";
        private OleDbConnection myConnection;

        public FormPoickBook()
        {
            InitializeComponent();
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
        }

        private void FormPoickBook_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet.Книги". При необходимости она может быть перемещена или удалена.
            //this.книгиTableAdapter.Fill(this.dataSet.Книги);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void FormPoickBook_FormClosing(object sender, FormClosingEventArgs e)
        {
            myConnection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string p = textBox1.Text;
            string query = "SELECT * FROM Книги WHERE [ФИО автора] LIKE '%" + p + "%' OR [Авторский код] LIKE '%" + p + "%' OR Описание LIKE '%" + p + "%' OR Раздел LIKE '%" + p + "%' OR Подраздел LIKE '%" + p + "%'";
            OleDbDataAdapter command = new OleDbDataAdapter(query, myConnection);
            DataTable qw = new DataTable();
            command.Fill(qw);
            dataGridView1.DataSource = qw;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Excel.Application exApp = new Excel.Application();

            exApp.Workbooks.Add();
            Excel.Worksheet wsh = (Excel.Worksheet)exApp.ActiveSheet;
            int i, j;
            for (i = 0; i <= dataGridView1.RowCount - 2; i++)
            {
                for (j = 0; j <= dataGridView1.ColumnCount - 1; j++)
                {
                    wsh.Cells[i + 1, j + 1] = dataGridView1[j, i].Value.ToString();
                }
            }
            exApp.Visible = true;
        }
    }
}
