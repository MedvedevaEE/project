﻿namespace WindowsFormsApp1
{


    public partial class библиотекаDataSet
    {
    }
}
namespace WindowsFormsApp1 {
    
    
    public partial class библиотекаDataSet {
    }
}
