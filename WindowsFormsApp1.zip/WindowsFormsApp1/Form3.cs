﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Информационно-справочная система Библиотека позволяет осуществлять работу с базой данных, хранящей информацию о книгах." +
                "\n" +
                "Для реализации какого-либо действия необходимо нажать кнопку, название которой совпадает с желаемым действием, располагающуюся на форме или выбрать соответствующий пункт главного меню." +
                "\n" +
                "Разработчик: Медведева Екатерина Евгеньевна", "О ПРОГРАММЕ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }


        private void добавлениеКнигиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAddBook f6 = new FormAddBook();
            f6.Owner = this;
            f6.Show();
            Form3 f4 = new Form3();
            f4.Owner = this;
            f4.Close();
        }

        private void списаниеКнигиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDropBook f7 = new FormDropBook();
            f7.Owner = this;
            f7.Show();
            Form3 f4 = new Form3();
            f4.Owner = this;
            f4.Close();
        }

        private void абонементToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAbonement f8 = new FormAbonement();
            f8.Owner = this;
            f8.Show();
            Form3 f4 = new Form3();
            f4.Owner = this;
            f4.Close();
        }

        private void книгToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPoickBook f9 = new FormPoickBook();
            f9.Owner = this;
            f9.Show();
            Form3 f4 = new Form3();
            f4.Owner = this;
            f4.Close();
        }

        private void читателейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPoickReaders f10 = new FormPoickReaders();
            f10.Owner = this;
            f10.Show();
            Form3 f4 = new Form3();
            f4.Owner = this;
            f4.Close();
        }

        private void абонементаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPoickAbonementa f11 = new FormPoickAbonementa();
            f11.Owner = this;
            f11.Show();
            Form3 f4 = new Form3();
            f4.Owner = this;
            f4.Close();
        }

        private void добавлениеЧитателейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAddReaders f12 = new FormAddReaders();
            f12.Owner = this;
            f12.Show();
            Form3 f4 = new Form3();
            f4.Owner = this;
            f4.Close();
        }
    }
}
