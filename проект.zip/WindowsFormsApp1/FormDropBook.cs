﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class FormDropBook : Form
    {
        public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= библиотека.mdb";
        private OleDbConnection myConnection;
        public FormDropBook()
        {
            InitializeComponent();
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
        }

        private void FormDropBook_Load(object sender, EventArgs e)
        {
            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "библиотекаDataSet.Списанные_книги". При необходимости она может быть перемещена или удалена.
            //this.списанные_книгиTableAdapter.Fill(this.библиотекаDataSet.Списанные_книги);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string inn = Convert.ToString(maskedTextBox5.Text);
            string isbn = Convert.ToString(maskedTextBox1.Text);
            string ds = Convert.ToString(maskedTextBox2.Text);
            string ps = Convert.ToString(textBox3.Text);
            string nps = Convert.ToString(maskedTextBox4.Text);            
            string query = "INSERT INTO [Списанные книги] ([Инвентарный номер], ISBN, [Дата списания], [Причины списания], [Номер протокола списания]) " +
            "VALUES ('" + inn + "','" + isbn + "','" + ds + "','" + ps + "','" + nps + "',)";
            OleDbDataAdapter command = new OleDbDataAdapter(query, myConnection);
            command.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Книга добавлена");
            this.списанные_книгиTableAdapter.Fill(this.библиотекаDataSet.Списанные_книги);
            maskedTextBox5.Clear();
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            maskedTextBox4.Clear();
            textBox3.Clear();
        }
    }
}
