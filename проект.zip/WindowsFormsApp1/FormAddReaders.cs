﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Configuration;




namespace WindowsFormsApp1
{
    public partial class FormAddReaders : Form
    {
        public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source = библиотека.mdb";
        private OleDbConnection myConnection;

        public FormAddReaders()
        {
            InitializeComponent();
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
        }

        private void FormAddReaders_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "библиотекаDataSet.Читатели". При необходимости она может быть перемещена или удалена.
            this.читателиTableAdapter.Fill(this.библиотекаDataSet.Читатели);

        }

        private void button1_Click(object sender, EventArgs e)
        {

            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string na = Convert.ToString(maskedTextBox1.Text);
            string f = Convert.ToString(textBox2.Text);
            string i = Convert.ToString(textBox3.Text);
            string o = Convert.ToString(textBox4.Text);
            string dol = Convert.ToString(comboBox1.Text);
            string p = Convert.ToString(maskedTextBox2.Text);
            string v = Convert.ToString(maskedTextBox3.Text);
            string query = "INSERT INTO Читатели([Читательский номер], Фамилия, Имя, Отчество, [Специальность/Должность], [Дата поступления], [Дата выпуска])" +
                " VALUES('" + na + "', '" + f + "', '" + i + "', '" + o + "', '" + dol + "', '" + p + "', '" + v + "')";
            OleDbDataAdapter command = new OleDbDataAdapter(query, myConnection);
            command.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Читатель добавлен");
            this.читателиTableAdapter.Fill(this.библиотекаDataSet.Читатели);
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            maskedTextBox3.Clear();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string nd = Convert.ToString(maskedTextBox4.Text);

            string query = "DELETE FROM Читатели WHERE [Читательский номер] = '" + nd + "'";
            OleDbDataAdapter command = new OleDbDataAdapter(query, myConnection);
            command.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Читатель удален");
            this.читателиTableAdapter.Fill(this.библиотекаDataSet.Читатели);           
            maskedTextBox4.Clear();
        }
    }
}
