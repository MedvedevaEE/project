﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class FormAddBook : Form
    {
        public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= библиотека.mdb";
        private OleDbConnection myConnection;

        public FormAddBook()
        {
            InitializeComponent();
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
        }

        private void FormAddBook_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "библиотекаDataSet.Книги". При необходимости она может быть перемещена или удалена.
            //this.книгиTableAdapter.Fill(this.библиотекаDataSet.Книги);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "библиотекаDataSet.Книги". При необходимости она может быть перемещена или удалена.
            //this.книгиTableAdapter.Fill(this.библиотекаDataSet.Книги);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void книгиBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            myConnection = new OleDbConnection(connectString);
            myConnection.Open();
            string inn = Convert.ToString(maskedTextBox5.Text);
            string isbn = Convert.ToString(maskedTextBox1.Text);
            string fio = Convert.ToString(maskedTextBox7.Text);
            string ak = Convert.ToString(maskedTextBox6.Text);
            string op = Convert.ToString(textBox5.Text);
            string r = Convert.ToString(comboBox2.Text);
            string pr = Convert.ToString(comboBox1.Text);
            string kol = Convert.ToString(maskedTextBox2.Text);
            string st = Convert.ToString(maskedTextBox3.Text);
            string dp = Convert.ToString(maskedTextBox4.Text);
            string query = "INSERT INTO Книги ([Инвентарный номер], ISBN, [ФИО автора], [Авторский код], Описание, Раздел, Подраздел, [Количество экземпляров], [Цена экземпляра], [Дата внесения в фонд]) " +
            "VALUES ('" + inn + "','" + isbn + "','" + fio + "','" + ak + "','" + op + "','" + r + "','" + pr + "','" + kol + "','" + st + "','" + dp + "')";
            OleDbDataAdapter command = new OleDbDataAdapter(query, myConnection);
            command.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Книга добавлена");
            this.книгиTableAdapter.Fill(this.библиотекаDataSet.Книги);
            maskedTextBox5.Clear();
            maskedTextBox1.Clear();
            maskedTextBox7.Clear();
            maskedTextBox6.Clear();
            textBox5.Clear();
            maskedTextBox2.Clear();
            maskedTextBox3.Clear();
            maskedTextBox4.Clear();
        }
    }
}
